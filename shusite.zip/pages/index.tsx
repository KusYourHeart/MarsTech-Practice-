import Image from 'next/image'
import BV1 from '../components/main_block/BV1';
import CV1 from '../components/main_block/CV1';

export default function Home() {
  return (
    <div>

      <BV1 >
        <CV1 />
      </BV1>

    </div>

  )
}
